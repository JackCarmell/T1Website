  
  <script defer src="https://unpkg.com/alpinejs@3.10.3/dist/cdn.min.js"></script>
  <header class="fixed flex w-full justify-between items-center px-4 md:px-12 bg-gray h-24 bg-green-700 z-100">
    <a href="#" class="items-center">
      <img src="<?php echo e(URL('stockImages/logo.png')); ?>" class="h-12" />
    </a>
    <nav>
      <button class="md:hidden" @click="navbarOpen = !navbarOpen">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
      <ul :class="{'translate-x-full' : !navbarOpen, 'translate-x-0' : navbarOpen}" class="
      fixed
      align-middle
      w-full
      right-0
      left-0
      min-h-screen
      bg-green-700  
      space-y-4
      p-4
      z-50
      mt-5
      transform
      transition
      duration-200
      translate-x-full
      md:relative
      md:flex
      md:min-h-0
      md:space-y-0
      md:space-x-6
      md:p-0
      md:translate-x-0
      md:m-0
      "
      >
        <li class="flex justify-center align-center">
          <a href="/" class="align-middle text-white">HOME</a>
        </li>
        <li class="flex justify-center align-center">
          <a href="<?php echo e(route('products')); ?>" class="align-middle text-white">SHOP</a>
        </li>
        <li class="flex justify-center align-center">
          <a href="<?php echo e(route('about')); ?>" class="align-middle text-white">ABOUT</a>
        </li>
        <li class="flex justify-center align-center">
          <a href="<?php echo e(route('contact')); ?>" class="align-middle text-white">CONTACT</a>
        </li>
        <li class="flex justify-center align-center">
          <a href="<?php echo e(route('basket')); ?>" class="align-middle text-white">BASKET</a>
        </li>
        <li class="flex justify-center align-center bg-green-400 rounded px-2 transition-colors duration-300
        font-semibold">
          <a href="<?php echo e(route('login')); ?>" class="text-white">Login</a>
        </li>
      </ul>
    </nav>
  </header>


  <?php /**PATH C:\Users\iwogr\Documents\Jack\T1Website\Teamproject1\resources\views/components/navbar.blade.php ENDPATH**/ ?>