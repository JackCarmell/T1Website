<footer class="text-center bg-green-500 py-4">
    <p class="text-white">1Market Ltd. | Birmingham, England, UK | Contact us today</p>
</footer><?php /**PATH C:\Users\iwogr\Documents\Jack\T1Website\Teamproject1\resources\views/components/footer.blade.php ENDPATH**/ ?>