@extends('layouts.app')

@section('content')

    <h1>Basket page</h1>
@endsection