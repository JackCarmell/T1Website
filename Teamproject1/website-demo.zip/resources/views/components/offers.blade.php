<div class="container text-center">
    <h3>Some Cool Offers</h3><br>
    <div class="row">
        <div class="col-sm-4">
        <img src="stockImages/NikeJordanTrainer.jpeg" class="img-responsive" style="width:100%" alt="Image">
        <p>Nike Jordan 4s Taupe Haze</p>
        </div>
        <div class="col-sm-4">
        <img src="stockImages/NikeTrainer1.jpeg" class="img-responsive" style="width:100%" alt="Image">
        <p>Yeezy 700 Waverunner</p>
        </div>
        <div class="col-sm-4">
        <div class="well">
            <p>Some text..</p>
        </div>
        <div class="well">
            <p>Some Text</p>
        </div>
        </div>
    </div>
</div>