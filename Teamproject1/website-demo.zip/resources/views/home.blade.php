@extends('layouts.app')

@section('content')

<x-carousel />
<x-offers />

@endsection
