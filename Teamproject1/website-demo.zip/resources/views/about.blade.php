@extends('layouts.app')

@section('content')

    <h1>About us page</h1>
@endsection